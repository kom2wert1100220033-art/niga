SERVICE JOBS — ГОТОВЫЙ ПРОЕКТ ПОД XAMPP

Что внутри:
1) database/service_jobs_xampp.sql — готовая база MySQL/MariaDB для phpMyAdmin
2) api/ — PHP backend без Laravel, сразу под XAMPP Apache + PHP
3) public/ — простой клиент на HTML/CSS/JS (fetch + DOM + localStorage)
4) postman/service_jobs_xampp.postman_collection.json — коллекция для Postman

КАК ЗАПУСТИТЬ В XAMPP

1. Установи и открой XAMPP.
2. Запусти Apache и MySQL.
3. Скопируй папку service-jobs-xampp целиком в:
   C:\xampp\htdocs\service-jobs-xampp
4. Открой phpMyAdmin:
   http://localhost/phpmyadmin
5. Импортируй файл:
   database/service_jobs_xampp.sql
6. Если у тебя стандартный XAMPP, api/config.php менять не нужно.
   Там уже стоит:
   host=localhost
   user=root
   password=''
   database=service_jobs_xampp

ПРОВЕРКА

1. API health:
   http://localhost/service-jobs-xampp/api/health

2. Клиент:
   http://localhost/service-jobs-xampp/public/

3. Демо-логины:
   store_manager / Store123!
   office_manager / Office123!
   hr_specialist / Hr123!

ЧТО УМЕЕТ ПРОЕКТ

Управляющий магазином:
- создать черновик задания
- отредактировать задание в статусе new
- отправить в офис
- отменить задание в статусе new или in_work
- смотреть свои задания

Управляющий офисом:
- смотреть задания в работе
- фильтровать и искать специалистов
- назначать специалиста
- создавать HR-заявку при отсутствии специалиста
- закрывать выполненные задания
- смотреть архив completed / closed

HR:
- смотреть HR-заявки
- брать заявку в работу
- добавлять нового специалиста
- отмечать HR-заявку как исполненную

ВАЖНО

1. Это именно вариант под XAMPP и phpMyAdmin.
2. Backend сделан на чистом PHP + PDO, чтобы у тебя все запустилось без Composer и без Laravel.
3. Для входа используется Bearer token, который создается через /login.
4. В public/ используется localStorage для хранения token и user.

ЕСЛИ /api/health НЕ ОТКРЫВАЕТСЯ

Проверь:
- Apache запущен
- MySQL запущен
- папка реально лежит в htdocs
- импорт базы прошел без ошибок
- mod_rewrite работает в Apache

Если rewrite вдруг не сработает, можно открыть напрямую:
http://localhost/service-jobs-xampp/api/index.php/health

НОРМАЛЬНЫЙ ПОРЯДОК СДАЧИ

1. Импортируешь БД в phpMyAdmin
2. Проверяешь API через /health
3. Заходишь в public/
4. Делаешь скрины входа и действий по ролям
5. При желании прогоняешь postman-коллекцию
