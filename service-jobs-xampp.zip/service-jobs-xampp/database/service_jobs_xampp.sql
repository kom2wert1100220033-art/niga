SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;

DROP DATABASE IF EXISTS service_jobs_xampp;
CREATE DATABASE service_jobs_xampp
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE service_jobs_xampp;

-- ============================================
-- База данных для XAMPP / phpMyAdmin
-- Предметная область: управление сервисными заданиями,
-- подбор специалистов и HR-заявки
-- СУБД: MySQL / MariaDB (совместимо с XAMPP)
-- ============================================

-- ----------------------------
-- Пользователи системы
-- ----------------------------
CREATE TABLE app_users (
    user_id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    role_code         ENUM('store_manager', 'office_manager', 'hr_specialist') NOT NULL,
    login             VARCHAR(50) NOT NULL,
    email             VARCHAR(120) NOT NULL,
    password_hash     VARCHAR(255) NOT NULL,
    first_name        VARCHAR(50) NOT NULL,
    last_name         VARCHAR(50) NOT NULL,
    phone             VARCHAR(20) NULL,
    is_active         TINYINT(1) NOT NULL DEFAULT 1,
    created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_app_users_login (login),
    UNIQUE KEY uq_app_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Токены авторизации API
-- ----------------------------
CREATE TABLE auth_tokens (
    token_id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id            BIGINT UNSIGNED NOT NULL,
    token              CHAR(64) NOT NULL,
    expires_at         DATETIME NOT NULL,
    created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (token_id),
    UNIQUE KEY uq_auth_tokens_token (token),
    KEY idx_auth_tokens_user (user_id),
    KEY idx_auth_tokens_expires (expires_at),
    CONSTRAINT fk_auth_tokens_user
        FOREIGN KEY (user_id) REFERENCES app_users(user_id)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Регионы
-- ----------------------------
CREATE TABLE regions (
    region_id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    region_name       VARCHAR(100) NOT NULL,
    PRIMARY KEY (region_id),
    UNIQUE KEY uq_regions_name (region_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Магазины
-- ----------------------------
CREATE TABLE stores (
    store_id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    store_name        VARCHAR(150) NOT NULL,
    region_id         BIGINT UNSIGNED NOT NULL,
    address           TEXT NOT NULL,
    manager_user_id   BIGINT UNSIGNED NULL,
    is_active         TINYINT(1) NOT NULL DEFAULT 1,
    created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (store_id),
    UNIQUE KEY uq_stores_name (store_name),
    UNIQUE KEY uq_stores_manager (manager_user_id),
    KEY idx_stores_region (region_id),
    CONSTRAINT fk_stores_region
        FOREIGN KEY (region_id) REFERENCES regions(region_id),
    CONSTRAINT fk_stores_manager
        FOREIGN KEY (manager_user_id) REFERENCES app_users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Справочник специализаций
-- ----------------------------
CREATE TABLE specialties (
    specialty_id      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    specialty_name    VARCHAR(100) NOT NULL,
    description       TEXT NULL,
    PRIMARY KEY (specialty_id),
    UNIQUE KEY uq_specialties_name (specialty_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- База специалистов
-- ----------------------------
CREATE TABLE specialists (
    specialist_id       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    last_name           VARCHAR(50) NOT NULL,
    first_name          VARCHAR(50) NOT NULL,
    middle_name         VARCHAR(50) NULL,
    phone               VARCHAR(20) NULL,
    email               VARCHAR(120) NULL,
    region_id           BIGINT UNSIGNED NOT NULL,
    contract_status     ENUM('pending', 'active', 'suspended', 'terminated') NOT NULL DEFAULT 'pending',
    is_available        TINYINT(1) NOT NULL DEFAULT 1,
    hire_date           DATE NULL,
    contract_number     VARCHAR(50) NULL,
    notes               TEXT NULL,
    created_by_user_id  BIGINT UNSIGNED NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (specialist_id),
    UNIQUE KEY uq_specialists_email (email),
    KEY idx_specialists_region (region_id),
    KEY idx_specialists_contract (region_id, contract_status, is_available),
    KEY idx_specialists_created_by (created_by_user_id),
    CONSTRAINT fk_specialists_region
        FOREIGN KEY (region_id) REFERENCES regions(region_id),
    CONSTRAINT fk_specialists_created_by
        FOREIGN KEY (created_by_user_id) REFERENCES app_users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Один специалист может иметь несколько специализаций
CREATE TABLE specialist_specialties (
    specialist_id      BIGINT UNSIGNED NOT NULL,
    specialty_id       BIGINT UNSIGNED NOT NULL,
    proficiency_level  SMALLINT NOT NULL DEFAULT 3,
    PRIMARY KEY (specialist_id, specialty_id),
    KEY idx_specialist_specialties_specialty (specialty_id),
    CONSTRAINT fk_ss_specialist
        FOREIGN KEY (specialist_id) REFERENCES specialists(specialist_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_ss_specialty
        FOREIGN KEY (specialty_id) REFERENCES specialties(specialty_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Задания на сервисные работы
-- ----------------------------
CREATE TABLE tasks (
    task_id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    store_id               BIGINT UNSIGNED NOT NULL,
    created_by_user_id     BIGINT UNSIGNED NOT NULL,
    title                  VARCHAR(200) NOT NULL,
    description            TEXT NULL,
    date_start             DATE NOT NULL,
    date_end               DATE NOT NULL,
    performer_wishes       TEXT NULL,
    status                 ENUM('new', 'in_work', 'completed', 'closed', 'cancelled') NOT NULL DEFAULT 'new',
    submitted_at           DATETIME NULL,
    assigned_specialist_id BIGINT UNSIGNED NULL,
    assigned_by_user_id    BIGINT UNSIGNED NULL,
    assigned_at            DATETIME NULL,
    closed_at              DATETIME NULL,
    cancelled_at           DATETIME NULL,
    created_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (task_id),
    KEY idx_tasks_status (status),
    KEY idx_tasks_store_dates (store_id, date_start, date_end),
    KEY idx_tasks_assigned_specialist (assigned_specialist_id),
    KEY idx_tasks_created_by (created_by_user_id),
    KEY idx_tasks_assigned_by (assigned_by_user_id),
    CONSTRAINT fk_tasks_store
        FOREIGN KEY (store_id) REFERENCES stores(store_id),
    CONSTRAINT fk_tasks_created_by
        FOREIGN KEY (created_by_user_id) REFERENCES app_users(user_id),
    CONSTRAINT fk_tasks_assigned_specialist
        FOREIGN KEY (assigned_specialist_id) REFERENCES specialists(specialist_id),
    CONSTRAINT fk_tasks_assigned_by
        FOREIGN KEY (assigned_by_user_id) REFERENCES app_users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Состав работ по заданию
CREATE TABLE task_work_items (
    task_work_item_id    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    task_id              BIGINT UNSIGNED NOT NULL,
    line_no              INT NOT NULL,
    work_name            VARCHAR(200) NOT NULL,
    specialty_id         BIGINT UNSIGNED NOT NULL,
    quantity             DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    comment_text         TEXT NULL,
    PRIMARY KEY (task_work_item_id),
    UNIQUE KEY uq_task_line (task_id, line_no),
    KEY idx_task_work_items_specialty (specialty_id),
    CONSTRAINT fk_task_work_items_task
        FOREIGN KEY (task_id) REFERENCES tasks(task_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_task_work_items_specialty
        FOREIGN KEY (specialty_id) REFERENCES specialties(specialty_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- История смены статусов задания
CREATE TABLE task_status_history (
    history_id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    task_id              BIGINT UNSIGNED NOT NULL,
    old_status           ENUM('new', 'in_work', 'completed', 'closed', 'cancelled') NULL,
    new_status           ENUM('new', 'in_work', 'completed', 'closed', 'cancelled') NOT NULL,
    changed_by_user_id   BIGINT UNSIGNED NULL,
    change_comment       TEXT NULL,
    changed_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (history_id),
    KEY idx_task_status_history_task (task_id, changed_at),
    CONSTRAINT fk_task_status_history_task
        FOREIGN KEY (task_id) REFERENCES tasks(task_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_task_status_history_user
        FOREIGN KEY (changed_by_user_id) REFERENCES app_users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Заявки на подбор персонала
-- ----------------------------
CREATE TABLE recruitment_requests (
    recruitment_request_id  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    task_id                 BIGINT UNSIGNED NOT NULL,
    specialty_id            BIGINT UNSIGNED NOT NULL,
    region_id               BIGINT UNSIGNED NOT NULL,
    created_by_user_id      BIGINT UNSIGNED NOT NULL,
    hr_user_id              BIGINT UNSIGNED NULL,
    status                  ENUM('new', 'in_work', 'fulfilled', 'cancelled') NOT NULL DEFAULT 'new',
    notes                   TEXT NULL,
    needed_from             DATE NOT NULL,
    needed_to               DATE NOT NULL,
    fulfilled_specialist_id BIGINT UNSIGNED NULL,
    created_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    started_at              DATETIME NULL,
    fulfilled_at            DATETIME NULL,
    PRIMARY KEY (recruitment_request_id),
    UNIQUE KEY uq_recruitment_task_spec (task_id, specialty_id),
    KEY idx_recruitment_status_region (status, region_id),
    KEY idx_recruitment_created_by (created_by_user_id),
    KEY idx_recruitment_hr_user (hr_user_id),
    KEY idx_recruitment_fulfilled_specialist (fulfilled_specialist_id),
    CONSTRAINT fk_recruitment_task
        FOREIGN KEY (task_id) REFERENCES tasks(task_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_recruitment_specialty
        FOREIGN KEY (specialty_id) REFERENCES specialties(specialty_id),
    CONSTRAINT fk_recruitment_region
        FOREIGN KEY (region_id) REFERENCES regions(region_id),
    CONSTRAINT fk_recruitment_created_by
        FOREIGN KEY (created_by_user_id) REFERENCES app_users(user_id),
    CONSTRAINT fk_recruitment_hr_user
        FOREIGN KEY (hr_user_id) REFERENCES app_users(user_id),
    CONSTRAINT fk_recruitment_fulfilled_specialist
        FOREIGN KEY (fulfilled_specialist_id) REFERENCES specialists(specialist_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- История статусов HR-заявки
CREATE TABLE recruitment_request_status_history (
    history_id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    recruitment_request_id   BIGINT UNSIGNED NOT NULL,
    old_status               ENUM('new', 'in_work', 'fulfilled', 'cancelled') NULL,
    new_status               ENUM('new', 'in_work', 'fulfilled', 'cancelled') NOT NULL,
    changed_by_user_id       BIGINT UNSIGNED NULL,
    change_comment           TEXT NULL,
    changed_at               DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (history_id),
    KEY idx_rr_status_history_request (recruitment_request_id, changed_at),
    CONSTRAINT fk_rr_status_history_request
        FOREIGN KEY (recruitment_request_id) REFERENCES recruitment_requests(recruitment_request_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_rr_status_history_user
        FOREIGN KEY (changed_by_user_id) REFERENCES app_users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DELIMITER $$

-- ----------------------------
-- Триггеры: задания
-- ----------------------------
CREATE TRIGGER trg_tasks_before_insert
BEFORE INSERT ON tasks
FOR EACH ROW
BEGIN
    IF NEW.date_end < NEW.date_start THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Дата окончания задания не может быть раньше даты начала';
    END IF;
END $$

CREATE TRIGGER trg_tasks_before_update
BEFORE UPDATE ON tasks
FOR EACH ROW
BEGIN
    IF OLD.status IN ('closed', 'cancelled') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Задание в конечном статусе недоступно для редактирования';
    END IF;

    IF NEW.date_end < NEW.date_start THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Дата окончания задания не может быть раньше даты начала';
    END IF;

    IF NEW.status <> OLD.status THEN
        CASE OLD.status
            WHEN 'new' THEN
                IF NEW.status NOT IN ('in_work', 'cancelled') THEN
                    SIGNAL SQLSTATE '45000'
                        SET MESSAGE_TEXT = 'Недопустимый переход статуса задания: new';
                END IF;

                IF NEW.status = 'in_work' THEN
                    SET NEW.submitted_at = IFNULL(NEW.submitted_at, NOW());
                END IF;

                IF NEW.status = 'cancelled' THEN
                    SET NEW.cancelled_at = IFNULL(NEW.cancelled_at, NOW());
                END IF;

            WHEN 'in_work' THEN
                IF NEW.status NOT IN ('completed', 'cancelled') THEN
                    SIGNAL SQLSTATE '45000'
                        SET MESSAGE_TEXT = 'Недопустимый переход статуса задания: in_work';
                END IF;

                IF NEW.status = 'completed' THEN
                    IF NEW.assigned_specialist_id IS NULL THEN
                        SIGNAL SQLSTATE '45000'
                            SET MESSAGE_TEXT = 'Нельзя перевести задание в completed без назначенного специалиста';
                    END IF;

                    SET NEW.assigned_at = IFNULL(NEW.assigned_at, NOW());
                END IF;

                IF NEW.status = 'cancelled' THEN
                    SET NEW.cancelled_at = IFNULL(NEW.cancelled_at, NOW());
                END IF;

            WHEN 'completed' THEN
                IF NEW.status <> 'closed' THEN
                    SIGNAL SQLSTATE '45000'
                        SET MESSAGE_TEXT = 'Из статуса completed можно перейти только в closed';
                END IF;

                SET NEW.closed_at = IFNULL(NEW.closed_at, NOW());

            ELSE
                SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'Переход из текущего статуса задания запрещен';
        END CASE;
    END IF;
END $$

CREATE TRIGGER trg_tasks_after_insert
AFTER INSERT ON tasks
FOR EACH ROW
BEGIN
    INSERT INTO task_status_history (
        task_id,
        old_status,
        new_status,
        changed_by_user_id,
        changed_at
    ) VALUES (
        NEW.task_id,
        NULL,
        NEW.status,
        NEW.created_by_user_id,
        NOW()
    );
END $$

CREATE TRIGGER trg_tasks_after_update
AFTER UPDATE ON tasks
FOR EACH ROW
BEGIN
    IF NEW.status <> OLD.status THEN
        INSERT INTO task_status_history (
            task_id,
            old_status,
            new_status,
            changed_by_user_id,
            changed_at
        ) VALUES (
            NEW.task_id,
            OLD.status,
            NEW.status,
            @app_user_id,
            NOW()
        );
    END IF;
END $$

-- ----------------------------
-- Триггеры: HR-заявки
-- ----------------------------
CREATE TRIGGER trg_recruitment_before_insert
BEFORE INSERT ON recruitment_requests
FOR EACH ROW
BEGIN
    IF NEW.needed_to < NEW.needed_from THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Дата окончания HR-заявки не может быть раньше даты начала';
    END IF;
END $$

CREATE TRIGGER trg_recruitment_before_update
BEFORE UPDATE ON recruitment_requests
FOR EACH ROW
BEGIN
    IF OLD.status IN ('fulfilled', 'cancelled') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'HR-заявка в конечном статусе недоступна для редактирования';
    END IF;

    IF NEW.needed_to < NEW.needed_from THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Дата окончания HR-заявки не может быть раньше даты начала';
    END IF;

    IF NEW.status <> OLD.status THEN
        CASE OLD.status
            WHEN 'new' THEN
                IF NEW.status NOT IN ('in_work', 'cancelled') THEN
                    SIGNAL SQLSTATE '45000'
                        SET MESSAGE_TEXT = 'Недопустимый переход статуса HR-заявки: new';
                END IF;

                IF NEW.status = 'in_work' THEN
                    SET NEW.started_at = IFNULL(NEW.started_at, NOW());
                END IF;

            WHEN 'in_work' THEN
                IF NEW.status NOT IN ('fulfilled', 'cancelled') THEN
                    SIGNAL SQLSTATE '45000'
                        SET MESSAGE_TEXT = 'Недопустимый переход статуса HR-заявки: in_work';
                END IF;

                IF NEW.status = 'fulfilled' THEN
                    IF NEW.fulfilled_specialist_id IS NULL THEN
                        SIGNAL SQLSTATE '45000'
                            SET MESSAGE_TEXT = 'Нельзя завершить HR-заявку без указанного специалиста';
                    END IF;

                    SET NEW.fulfilled_at = IFNULL(NEW.fulfilled_at, NOW());
                END IF;

            ELSE
                SIGNAL SQLSTATE '45000'
                    SET MESSAGE_TEXT = 'Переход из текущего статуса HR-заявки запрещен';
        END CASE;
    END IF;
END $$

CREATE TRIGGER trg_recruitment_after_insert
AFTER INSERT ON recruitment_requests
FOR EACH ROW
BEGIN
    INSERT INTO recruitment_request_status_history (
        recruitment_request_id,
        old_status,
        new_status,
        changed_by_user_id,
        changed_at
    ) VALUES (
        NEW.recruitment_request_id,
        NULL,
        NEW.status,
        NEW.created_by_user_id,
        NOW()
    );
END $$

CREATE TRIGGER trg_recruitment_after_update
AFTER UPDATE ON recruitment_requests
FOR EACH ROW
BEGIN
    IF NEW.status <> OLD.status THEN
        INSERT INTO recruitment_request_status_history (
            recruitment_request_id,
            old_status,
            new_status,
            changed_by_user_id,
            changed_at
        ) VALUES (
            NEW.recruitment_request_id,
            OLD.status,
            NEW.status,
            @app_user_id,
            NOW()
        );
    END IF;
END $$

DELIMITER ;

-- ----------------------------
-- Представления
-- ----------------------------
CREATE OR REPLACE VIEW v_tasks_in_work AS
SELECT
    t.task_id,
    t.title,
    t.date_start,
    t.date_end,
    t.status,
    s.store_name,
    r.region_name,
    t.performer_wishes,
    t.created_at,
    t.submitted_at
FROM tasks t
JOIN stores s ON s.store_id = t.store_id
JOIN regions r ON r.region_id = s.region_id
WHERE t.status = 'in_work';

CREATE OR REPLACE VIEW v_task_archive AS
SELECT
    t.task_id,
    t.title,
    t.date_start,
    t.date_end,
    t.status,
    s.store_name,
    sp.specialist_id,
    CONCAT_WS(' ', sp.last_name, sp.first_name, sp.middle_name) AS specialist_full_name,
    t.assigned_at,
    t.closed_at
FROM tasks t
JOIN stores s ON s.store_id = t.store_id
LEFT JOIN specialists sp ON sp.specialist_id = t.assigned_specialist_id
WHERE t.status IN ('completed', 'closed');

CREATE OR REPLACE VIEW v_specialists_search AS
SELECT
    sp.specialist_id,
    CONCAT_WS(' ', sp.last_name, sp.first_name, sp.middle_name) AS specialist_full_name,
    sp.phone,
    sp.email,
    rg.region_name,
    sp.contract_status,
    sp.is_available,
    GROUP_CONCAT(DISTINCT st.specialty_name ORDER BY st.specialty_name SEPARATOR ', ') AS specialties
FROM specialists sp
JOIN regions rg ON rg.region_id = sp.region_id
LEFT JOIN specialist_specialties ss ON ss.specialist_id = sp.specialist_id
LEFT JOIN specialties st ON st.specialty_id = ss.specialty_id
GROUP BY
    sp.specialist_id,
    sp.last_name,
    sp.first_name,
    sp.middle_name,
    sp.phone,
    sp.email,
    rg.region_name,
    sp.contract_status,
    sp.is_available;

-- ----------------------------
-- Демо-данные
-- ----------------------------
INSERT INTO regions (region_id, region_name) VALUES
    (1, 'Москва'),
    (2, 'Санкт-Петербург'),
    (3, 'Казань');

INSERT INTO specialties (specialty_id, specialty_name, description) VALUES
    (1, 'Электрик', 'Электромонтаж и обслуживание электрооборудования'),
    (2, 'Сантехник', 'Ремонт и обслуживание сантехнических систем'),
    (3, 'Клининг', 'Уборка и санитарное обслуживание'),
    (4, 'Монтажник', 'Монтаж оборудования и конструкций');

-- Пароли для входа:
-- store_manager  / Store123!
-- office_manager / Office123!
-- hr_specialist  / Hr123!
INSERT INTO app_users (
    user_id, role_code, login, email, password_hash, first_name, last_name, phone, is_active
) VALUES
    (1, 'store_manager',  'store_manager',  'store_manager@example.com',  '$2y$12$IWznLYzoYE4RL6ppRvQUDebtZx8xwm98xSv9sbl8PFXASyb8jUesC', 'Иван',   'Сериков',  '+7-999-000-00-01', 1),
    (2, 'office_manager', 'office_manager', 'office_manager@example.com', '$2y$12$YXOp5cGBHtC8D4OuuL5Yae6/SybmM/vb9KxszKC8ya4SWm4dX2.LG', 'Алишер','Шавхалов', '+7-999-000-00-02', 1),
    (3, 'hr_specialist',  'hr_specialist',  'hr_specialist@example.com',  '$2y$12$U/ayYO1h6Nn31FnNYuC7venRkMDWySIyE3J0XnpSOtE0P3E0Mn9TW', 'Мария',  'Иванова',  '+7-999-000-00-03', 1);

INSERT INTO stores (
    store_id, store_name, region_id, address, manager_user_id, is_active
) VALUES
    (1, 'Магазин ТЦ Север', 1, 'г. Москва, ул. Центральная, д. 10', 1, 1),
    (2, 'Магазин Невский', 2, 'г. Санкт-Петербург, Невский проспект, д. 20', NULL, 1);

INSERT INTO specialists (
    specialist_id, last_name, first_name, middle_name, phone, email, region_id, contract_status,
    is_available, hire_date, contract_number, notes, created_by_user_id
) VALUES
    (1, 'Петров',  'Алексей', 'Игоревич',    '+7-900-111-11-11', 'petrov@example.com',   1, 'active',    1, '2025-05-10', 'DOG-001', 'Электрик с допуском', 3),
    (2, 'Сидоров', 'Никита',  'Андреевич',   '+7-900-222-22-22', 'sidorov@example.com',  1, 'active',    1, '2025-08-01', 'DOG-002', 'Специалист по клинингу', 3),
    (3, 'Орлова',  'Анна',    'Сергеевна',   '+7-900-333-33-33', 'orlova@example.com',   2, 'suspended', 0, '2024-11-15', 'DOG-003', 'Договор временно приостановлен', 3),
    (4, 'Ким',     'Денис',   'Олегович',    '+7-900-444-44-44', 'kim@example.com',      1, 'active',    1, '2026-02-20', 'DOG-004', 'Монтажник широкого профиля', 3);

INSERT INTO specialist_specialties (specialist_id, specialty_id, proficiency_level) VALUES
    (1, 1, 5),
    (2, 3, 4),
    (3, 2, 4),
    (4, 4, 5),
    (4, 1, 3);

INSERT INTO tasks (
    task_id, store_id, created_by_user_id, title, description, date_start, date_end,
    performer_wishes, status, submitted_at, assigned_specialist_id, assigned_by_user_id,
    assigned_at, closed_at, cancelled_at, created_at
) VALUES
    (1, 1, 1, 'Замена освещения в торговом зале', 'Нужно заменить 6 потолочных светильников', '2026-03-21', '2026-03-22', 'Желателен электрик с опытом работы в торговых помещениях', 'new',       NULL,                   NULL, NULL, NULL,                 NULL,                 NULL,                 '2026-03-19 09:00:00'),
    (2, 1, 1, 'Проверка сантехники в санузле',    'Падает давление воды, нужна диагностика',   '2026-03-23', '2026-03-24', 'Нужен сантехник, желательно по Москве',                         'in_work',   '2026-03-19 09:30:00', NULL, NULL, NULL,                 NULL,                 NULL,                 '2026-03-19 09:20:00'),
    (3, 1, 1, 'Установка новой вывески',          'Требуется монтаж и подключение подсветки',  '2026-03-25', '2026-03-26', 'Можно назначить монтажника или электрика',                     'completed', '2026-03-19 10:10:00', 4,    2,    '2026-03-19 11:00:00', NULL,                 NULL,                 '2026-03-19 10:00:00'),
    (4, 1, 1, 'Глубокая уборка складской зоны',   'После поставки нужно провести уборку',      '2026-03-18', '2026-03-18', 'Нужна аккуратная уборка без остановки работы магазина',       'closed',    '2026-03-18 08:30:00', 2,    2,    '2026-03-18 10:00:00', '2026-03-18 18:00:00', NULL,                 '2026-03-18 08:00:00'),
    (5, 1, 1, 'Ремонт розетки у кассы',           'Задание создано по ошибке, ремонт не нужен', '2026-03-20', '2026-03-20', 'Без пожеланий',                                                  'cancelled', NULL,                   NULL, NULL, NULL,                 NULL,                 '2026-03-19 12:00:00', '2026-03-19 11:50:00'),
    (6, 1, 1, 'Монтаж стеллажа у входа',          'Нужно собрать и закрепить новый стеллаж',   '2026-03-27', '2026-03-28', 'Желателен монтажник по Москве',                                  'in_work',   '2026-03-19 13:00:00', NULL, NULL, NULL,                 NULL,                 NULL,                 '2026-03-19 12:40:00');

INSERT INTO task_work_items (
    task_work_item_id, task_id, line_no, work_name, specialty_id, quantity, comment_text
) VALUES
    (1, 1, 1, 'Замена светильников',       1, 6.00, 'Высота потолков около 3 метров'),
    (2, 2, 1, 'Диагностика труб',          2, 1.00, 'Проверить причину перепадов давления'),
    (3, 3, 1, 'Монтаж вывески',            4, 1.00, 'Крепление на фасад'),
    (4, 3, 2, 'Подключение подсветки',     1, 1.00, 'Проверить питание и автомат'),
    (5, 4, 1, 'Уборка складской зоны',     3, 1.00, 'Обязательна сухая и влажная уборка'),
    (6, 5, 1, 'Осмотр розетки',            1, 1.00, 'Тестовое ошибочное задание'),
    (7, 6, 1, 'Сборка стеллажа',           4, 1.00, 'Необходимо закрепление к стене');

INSERT INTO recruitment_requests (
    recruitment_request_id, task_id, specialty_id, region_id, created_by_user_id,
    hr_user_id, status, notes, needed_from, needed_to, fulfilled_specialist_id,
    created_at, started_at, fulfilled_at
) VALUES
    (1, 2, 2, 1, 2, NULL, 'new',       'Подходящего сантехника в активной базе не найдено', '2026-03-23', '2026-03-24', NULL, '2026-03-19 10:40:00', NULL,                 NULL),
    (2, 6, 4, 1, 2, 3,    'fulfilled', 'Кандидат найден и добавлен в базу HR-специалистом', '2026-03-27', '2026-03-28', 4,    '2026-03-19 13:10:00', '2026-03-19 13:30:00', '2026-03-19 14:20:00');

-- Очищаем автосгенерированную триггерами историю и заполняем её понятными примерами
DELETE FROM task_status_history;
DELETE FROM recruitment_request_status_history;

INSERT INTO task_status_history (task_id, old_status, new_status, changed_by_user_id, changed_at, change_comment) VALUES
    (1, NULL,       'new',       1, '2026-03-19 09:00:00', 'Создан черновик задания'),
    (2, NULL,       'new',       1, '2026-03-19 09:20:00', 'Создано новое задание'),
    (2, 'new',      'in_work',   1, '2026-03-19 09:30:00', 'Отправлено в офис'),
    (3, NULL,       'new',       1, '2026-03-19 10:00:00', 'Создано новое задание'),
    (3, 'new',      'in_work',   1, '2026-03-19 10:10:00', 'Отправлено в офис'),
    (3, 'in_work',  'completed', 2, '2026-03-19 11:00:00', 'Назначен специалист'),
    (4, NULL,       'new',       1, '2026-03-18 08:00:00', 'Создано новое задание'),
    (4, 'new',      'in_work',   1, '2026-03-18 08:30:00', 'Отправлено в офис'),
    (4, 'in_work',  'completed', 2, '2026-03-18 10:00:00', 'Назначен специалист'),
    (4, 'completed','closed',    2, '2026-03-18 18:00:00', 'Работы подтверждены и задание закрыто'),
    (5, NULL,       'new',       1, '2026-03-19 11:50:00', 'Создано новое задание'),
    (5, 'new',      'cancelled', 1, '2026-03-19 12:00:00', 'Задание отменено управляющим магазином'),
    (6, NULL,       'new',       1, '2026-03-19 12:40:00', 'Создано новое задание'),
    (6, 'new',      'in_work',   1, '2026-03-19 13:00:00', 'Отправлено в офис');

INSERT INTO recruitment_request_status_history (
    recruitment_request_id, old_status, new_status, changed_by_user_id, changed_at, change_comment
) VALUES
    (1, NULL,      'new',       2, '2026-03-19 10:40:00', 'Создана заявка на подбор'),
    (2, NULL,      'new',       2, '2026-03-19 13:10:00', 'Создана заявка на подбор'),
    (2, 'new',     'in_work',   3, '2026-03-19 13:30:00', 'HR взял заявку в работу'),
    (2, 'in_work', 'fulfilled', 3, '2026-03-19 14:20:00', 'Кандидат найден и добавлен в базу');

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================
-- Примеры для приложения / phpMyAdmin
-- ============================================
-- 1. Указать пользователя сессии перед UPDATE для корректной записи в историю:
--    SET @app_user_id = 2;
--
-- 2. Отправить задание в офис:
--    UPDATE tasks
--    SET status = 'in_work'
--    WHERE task_id = 1 AND status = 'new';
--
-- 3. Назначить специалиста и перевести в выполнено:
--    SET @app_user_id = 2;
--    UPDATE tasks
--    SET assigned_specialist_id = 1,
--        assigned_by_user_id = 2,
--        status = 'completed'
--    WHERE task_id = 2 AND status = 'in_work';
--
-- 4. Закрыть выполненное задание:
--    SET @app_user_id = 2;
--    UPDATE tasks
--    SET status = 'closed'
--    WHERE task_id = 3 AND status = 'completed';
--
-- 5. Взять HR-заявку в работу:
--    SET @app_user_id = 3;
--    UPDATE recruitment_requests
--    SET status = 'in_work',
--        hr_user_id = 3
--    WHERE recruitment_request_id = 1 AND status = 'new';
