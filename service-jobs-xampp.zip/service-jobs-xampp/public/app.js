const API_BASE = '../api';

const state = {
  token: localStorage.getItem('service_jobs_token') || '',
  user: JSON.parse(localStorage.getItem('service_jobs_user') || 'null'),
  specialties: [],
  stores: [],
  currentFilter: 'all',
};

const elements = {
  authCard: document.getElementById('auth-card'),
  appCard: document.getElementById('app-card'),
  loginForm: document.getElementById('login-form'),
  meBox: document.getElementById('me-box'),
  messageBox: document.getElementById('message-box'),
  logoutBtn: document.getElementById('logout-btn'),
  refreshAll: document.getElementById('refresh-all'),
  storeSection: document.getElementById('store-section'),
  officeSection: document.getElementById('office-section'),
  hrSection: document.getElementById('hr-section'),
  createTaskForm: document.getElementById('create-task-form'),
  storeTasks: document.getElementById('store-tasks'),
  officeTasks: document.getElementById('office-tasks'),
  archiveTasks: document.getElementById('archive-tasks'),
  requestsList: document.getElementById('requests-list'),
  specialistsList: document.getElementById('specialists-list'),
  addWorkItem: document.getElementById('add-work-item'),
  workItems: document.getElementById('work-items'),
  workItemTemplate: document.getElementById('work-item-template'),
  fillStore: document.getElementById('fill-store'),
  fillOffice: document.getElementById('fill-office'),
  fillHr: document.getElementById('fill-hr'),
  searchSpecialistsForm: document.getElementById('search-specialists-form'),
  filterSpecialty: document.getElementById('filter-specialty'),
  regionSelect: document.getElementById('region-select'),
  specialtiesMulti: document.getElementById('specialties-multi'),
  addSpecialistForm: document.getElementById('add-specialist-form'),
  filters: [...document.querySelectorAll('.task-filter')],
};

function showMessage(text, type = 'success') {
  elements.messageBox.textContent = text;
  elements.messageBox.className = `message ${type}`;
  elements.messageBox.classList.remove('hidden');
}

function clearMessage() {
  elements.messageBox.classList.add('hidden');
  elements.messageBox.textContent = '';
}

async function api(path, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (state.token) {
    headers.Authorization = `Bearer ${state.token}`;
  }

  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.ok === false) {
    throw new Error(data.message || 'Ошибка запроса');
  }
  return data;
}

function setAuth(data) {
  state.token = data.token;
  state.user = data.user;
  localStorage.setItem('service_jobs_token', state.token);
  localStorage.setItem('service_jobs_user', JSON.stringify(state.user));
}

function logout() {
  state.token = '';
  state.user = null;
  localStorage.removeItem('service_jobs_token');
  localStorage.removeItem('service_jobs_user');
  renderAuthState();
}

function renderAuthState() {
  const loggedIn = Boolean(state.token && state.user);
  elements.authCard.classList.toggle('hidden', loggedIn);
  elements.appCard.classList.toggle('hidden', !loggedIn);
  elements.storeSection.classList.add('hidden');
  elements.officeSection.classList.add('hidden');
  elements.hrSection.classList.add('hidden');

  if (!loggedIn) {
    elements.meBox.innerHTML = '';
    return;
  }

  elements.meBox.innerHTML = `
    <div><strong>${state.user.full_name || state.user.login}</strong></div>
    <div>Роль: <span class="badge">${state.user.role_code}</span></div>
    <div>Логин: ${state.user.login}</div>
    ${state.user.store_name ? `<div>Магазин: ${state.user.store_name}</div>` : ''}
  `;

  if (state.user.role_code === 'store_manager') {
    elements.storeSection.classList.remove('hidden');
  }
  if (state.user.role_code === 'office_manager') {
    elements.officeSection.classList.remove('hidden');
  }
  if (state.user.role_code === 'hr_specialist') {
    elements.hrSection.classList.remove('hidden');
  }
}

function fillLogin(username, password) {
  elements.loginForm.username.value = username;
  elements.loginForm.password.value = password;
}

function optionList(items, valueKey, labelKey, includeEmpty = true) {
  const parts = [];
  if (includeEmpty) {
    parts.push('<option value="">— выбрать —</option>');
  }
  for (const item of items) {
    parts.push(`<option value="${item[valueKey]}">${item[labelKey]}</option>`);
  }
  return parts.join('');
}

function addWorkItemRow() {
  const node = elements.workItemTemplate.content.cloneNode(true);
  const wrapper = node.querySelector('.work-item');
  const select = node.querySelector('select[data-name="specialty_id"]');
  select.innerHTML = optionList(state.specialties, 'specialty_id', 'specialty_name');
  wrapper.querySelector('.remove-item').addEventListener('click', () => wrapper.remove());
  elements.workItems.appendChild(node);
}

function collectWorkItems() {
  return [...elements.workItems.querySelectorAll('.work-item')].map((item) => ({
    work_name: item.querySelector('[data-name="work_name"]').value.trim(),
    specialty_id: Number(item.querySelector('[data-name="specialty_id"]').value),
    quantity: Number(item.querySelector('[data-name="quantity"]').value || 1),
    comment_text: item.querySelector('[data-name="comment_text"]').value.trim(),
  })).filter((item) => item.work_name && item.specialty_id);
}

function renderItems(container, items, builder) {
  if (!items.length) {
    container.innerHTML = '<div class="hint">Пока пусто.</div>';
    return;
  }
  container.innerHTML = `<div class="item-list">${items.map(builder).join('')}</div>`;
}

async function loadReferenceData() {
  const [specialties, stores] = await Promise.all([
    api('/specialties'),
    api('/stores'),
  ]);

  state.specialties = specialties.items;
  state.stores = stores.items;
  elements.filterSpecialty.innerHTML = optionList(state.specialties, 'specialty_id', 'specialty_name');
  elements.specialtiesMulti.innerHTML = optionList(state.specialties, 'specialty_id', 'specialty_name', false);
  elements.regionSelect.innerHTML = [
    '<option value="1">Москва</option>',
    '<option value="2">Санкт-Петербург</option>',
    '<option value="3">Казань</option>',
  ].join('');

  if (!elements.workItems.children.length) {
    addWorkItemRow();
  }
}

async function loadStoreTasks() {
  const query = state.currentFilter === 'all' ? '' : `?status=${state.currentFilter}`;
  const data = await api(`/tasks${query}`);
  renderItems(elements.storeTasks, data.items, (task) => `
    <div class="item">
      <h5>${task.title}</h5>
      <div class="meta">
        <div><span class="badge">${task.status}</span> ${task.store_name}</div>
        <div>Срок: ${task.date_start} — ${task.date_end}</div>
        <div>Пожелания: ${task.performer_wishes || '—'}</div>
        <div>Назначенный специалист: ${task.specialist_full_name || 'еще не назначен'}</div>
      </div>
      <div class="actions">
        ${task.status === 'new' ? `<button data-action="submit-task" data-id="${task.task_id}">Отправить в офис</button>` : ''}
        ${['new', 'in_work'].includes(task.status) ? `<button class="secondary" data-action="cancel-task" data-id="${task.task_id}">Отменить</button>` : ''}
      </div>
    </div>
  `);
}

async function loadOfficeTasks() {
  const inWork = await api('/tasks?status=in_work');
  const archive = await api('/tasks?status=completed,closed');

  renderItems(elements.officeTasks, inWork.items, (task) => `
    <div class="item">
      <h5>${task.title}</h5>
      <div class="meta">
        <div><span class="badge">${task.status}</span> ${task.store_name} / ${task.region_name}</div>
        <div>Срок: ${task.date_start} — ${task.date_end}</div>
        <div>Описание: ${task.description || '—'}</div>
      </div>
      <div class="actions">
        <input type="number" min="1" placeholder="specialist_id" data-specialist-input="${task.task_id}">
        <button data-action="assign-task" data-id="${task.task_id}">Назначить специалиста</button>
        <select data-request-specialty="${task.task_id}">${optionList(state.specialties, 'specialty_id', 'specialty_name')}</select>
        <button class="secondary" data-action="create-request" data-id="${task.task_id}">Создать HR-заявку</button>
      </div>
    </div>
  `);

  renderItems(elements.archiveTasks, archive.items, (task) => `
    <div class="item">
      <h5>${task.title}</h5>
      <div class="meta">
        <div><span class="badge">${task.status}</span> ${task.store_name}</div>
        <div>Срок: ${task.date_start} — ${task.date_end}</div>
        <div>Специалист: ${task.specialist_full_name || '—'}</div>
        ${task.status === 'completed' ? `<div class="actions"><button data-action="close-task" data-id="${task.task_id}">Закрыть задание</button></div>` : ''}
      </div>
    </div>
  `);
}

async function loadSpecialists(params = {}) {
  const query = new URLSearchParams(params).toString();
  const data = await api(`/specialists${query ? `?${query}` : ''}`);
  renderItems(elements.specialistsList, data.items, (item) => `
    <div class="item">
      <h5>${item.specialist_full_name}</h5>
      <div class="meta">
        <div>ID: ${item.specialist_id}</div>
        <div>Регион: ${item.region_name}</div>
        <div>Статус договора: ${item.contract_status}</div>
        <div>Доступен: ${Number(item.is_available) === 1 ? 'да' : 'нет'}</div>
        <div>Специализации: ${item.specialties || '—'}</div>
      </div>
    </div>
  `);
}

async function loadRequests() {
  const data = await api('/recruitment-requests');
  renderItems(elements.requestsList, data.items, (item) => `
    <div class="item">
      <h5>${item.task_title}</h5>
      <div class="meta">
        <div><span class="badge">${item.status}</span> ${item.specialty_name} / ${item.region_name}</div>
        <div>Срок: ${item.needed_from} — ${item.needed_to}</div>
        <div>HR: ${item.hr_login || 'не назначен'}</div>
        <div>Исполненный специалист: ${item.fulfilled_specialist_name || '—'}</div>
      </div>
      <div class="actions">
        ${item.status === 'new' ? `<button data-action="take-request" data-id="${item.recruitment_request_id}">Взять в работу</button>` : ''}
        ${item.status === 'in_work' ? `<input type="number" min="1" placeholder="fulfilled_specialist_id" data-fulfill-input="${item.recruitment_request_id}">` : ''}
        ${item.status === 'in_work' ? `<button class="secondary" data-action="fulfill-request" data-id="${item.recruitment_request_id}">Исполнить заявку</button>` : ''}
      </div>
    </div>
  `);
}

async function refreshAll() {
  clearMessage();
  renderAuthState();
  if (!state.token || !state.user) {
    return;
  }
  await loadReferenceData();

  if (state.user.role_code === 'store_manager') {
    await loadStoreTasks();
  }
  if (state.user.role_code === 'office_manager') {
    await Promise.all([loadOfficeTasks(), loadSpecialists({ contract_status: 'active', is_available: 1 })]);
  }
  if (state.user.role_code === 'hr_specialist') {
    await loadRequests();
  }
}

async function handleLogin(event) {
  event.preventDefault();
  try {
    clearMessage();
    const formData = new FormData(elements.loginForm);
    const data = await api('/login', {
      method: 'POST',
      body: JSON.stringify({
        username: formData.get('username'),
        password: formData.get('password'),
      }),
    });
    setAuth(data);
    showMessage('Вход выполнен.');
    await refreshAll();
  } catch (error) {
    showMessage(error.message, 'error');
  }
}

async function handleCreateTask(event) {
  event.preventDefault();
  try {
    const formData = new FormData(elements.createTaskForm);
    await api('/tasks', {
      method: 'POST',
      body: JSON.stringify({
        title: formData.get('title'),
        description: formData.get('description'),
        date_start: formData.get('date_start'),
        date_end: formData.get('date_end'),
        performer_wishes: formData.get('performer_wishes'),
        work_items: collectWorkItems(),
      }),
    });
    elements.createTaskForm.reset();
    elements.workItems.innerHTML = '';
    addWorkItemRow();
    showMessage('Черновик создан.');
    await loadStoreTasks();
  } catch (error) {
    showMessage(error.message, 'error');
  }
}

async function handleActionClick(event) {
  const button = event.target.closest('button[data-action]');
  if (!button) return;

  const { action, id } = button.dataset;
  try {
    if (action === 'submit-task') {
      await api(`/tasks/${id}/submit`, { method: 'POST' });
      showMessage('Задание отправлено в офис.');
      await loadStoreTasks();
    }

    if (action === 'cancel-task') {
      await api(`/tasks/${id}/cancel`, { method: 'POST' });
      showMessage('Задание отменено.');
      await loadStoreTasks();
    }

    if (action === 'assign-task') {
      const input = document.querySelector(`[data-specialist-input="${id}"]`);
      const specialistId = Number(input.value);
      await api(`/tasks/${id}/assign-specialist`, {
        method: 'POST',
        body: JSON.stringify({ specialist_id: specialistId }),
      });
      showMessage('Специалист назначен.');
      await loadOfficeTasks();
    }

    if (action === 'create-request') {
      const select = document.querySelector(`[data-request-specialty="${id}"]`);
      await api(`/tasks/${id}/recruitment-requests`, {
        method: 'POST',
        body: JSON.stringify({ specialty_id: Number(select.value), notes: 'Создано из клиентского интерфейса.' }),
      });
      showMessage('HR-заявка создана.');
      await loadOfficeTasks();
    }

    if (action === 'close-task') {
      await api(`/tasks/${id}/close`, { method: 'POST' });
      showMessage('Задание закрыто.');
      await loadOfficeTasks();
    }

    if (action === 'take-request') {
      await api(`/recruitment-requests/${id}/take`, { method: 'POST' });
      showMessage('HR-заявка взята в работу.');
      await loadRequests();
    }

    if (action === 'fulfill-request') {
      const input = document.querySelector(`[data-fulfill-input="${id}"]`);
      const fulfilledSpecialistId = Number(input.value);
      await api(`/recruitment-requests/${id}/fulfill`, {
        method: 'POST',
        body: JSON.stringify({ fulfilled_specialist_id: fulfilledSpecialistId }),
      });
      showMessage('HR-заявка исполнена.');
      await loadRequests();
    }
  } catch (error) {
    showMessage(error.message, 'error');
  }
}

async function handleSearchSpecialists(event) {
  event.preventDefault();
  try {
    const formData = new FormData(elements.searchSpecialistsForm);
    await loadSpecialists({
      specialty_id: formData.get('specialty_id'),
      contract_status: formData.get('contract_status'),
      is_available: 1,
    });
    showMessage('Поиск специалистов выполнен.');
  } catch (error) {
    showMessage(error.message, 'error');
  }
}

async function handleAddSpecialist(event) {
  event.preventDefault();
  try {
    const formData = new FormData(elements.addSpecialistForm);
    const specialtyIds = [...elements.specialtiesMulti.selectedOptions].map((option) => Number(option.value));
    const payload = Object.fromEntries(formData.entries());
    payload.specialty_ids = specialtyIds;
    await api('/specialists', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    elements.addSpecialistForm.reset();
    showMessage('Новый специалист добавлен.');
  } catch (error) {
    showMessage(error.message, 'error');
  }
}

elements.loginForm.addEventListener('submit', handleLogin);
elements.logoutBtn.addEventListener('click', logout);
elements.refreshAll.addEventListener('click', () => refreshAll().catch((error) => showMessage(error.message, 'error')));
elements.addWorkItem.addEventListener('click', addWorkItemRow);
elements.createTaskForm.addEventListener('submit', handleCreateTask);
document.body.addEventListener('click', handleActionClick);
elements.searchSpecialistsForm.addEventListener('submit', handleSearchSpecialists);
elements.addSpecialistForm.addEventListener('submit', handleAddSpecialist);
elements.fillStore.addEventListener('click', () => fillLogin('store_manager', 'Store123!'));
elements.fillOffice.addEventListener('click', () => fillLogin('office_manager', 'Office123!'));
elements.fillHr.addEventListener('click', () => fillLogin('hr_specialist', 'Hr123!'));

elements.filters.forEach((button) => {
  button.addEventListener('click', () => {
    elements.filters.forEach((item) => item.classList.remove('active'));
    button.classList.add('active');
    state.currentFilter = button.dataset.taskFilter;
    loadStoreTasks().catch((error) => showMessage(error.message, 'error'));
  });
});

renderAuthState();
if (state.token && state.user) {
  refreshAll().catch((error) => {
    showMessage(error.message, 'error');
    if (error.message.includes('токен')) {
      logout();
    }
  });
}
