<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$config = require __DIR__ . '/config.php';

function jsonResponse(array $payload, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function requestBody(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        jsonResponse(['ok' => false, 'message' => 'Некорректный JSON в теле запроса.'], 400);
    }

    return $data;
}

function db(): PDO
{
    static $pdo = null;
    global $config;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $config['db']['host'],
        $config['db']['port'],
        $config['db']['name'],
        $config['db']['charset']
    );

    try {
        $pdo = new PDO($dsn, $config['db']['user'], $config['db']['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (PDOException $e) {
        jsonResponse([
            'ok' => false,
            'message' => 'Не удалось подключиться к MySQL. Проверь XAMPP, phpMyAdmin и настройки в api/config.php.',
            'error' => $e->getMessage(),
        ], 500);
    }

    return $pdo;
}

function normalizePath(): string
{
    $uriPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/';
    $scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');

    if ($scriptDir !== '' && $scriptDir !== '/' && str_starts_with($uriPath, $scriptDir)) {
        $uriPath = substr($uriPath, strlen($scriptDir));
    }

    $uriPath = '/' . trim($uriPath, '/');

    if (str_starts_with($uriPath, '/index.php')) {
        $uriPath = substr($uriPath, strlen('/index.php')) ?: '/';
    }

    return $uriPath === '//' ? '/' : $uriPath;
}

function routeSegments(): array
{
    $path = trim(normalizePath(), '/');
    return $path === '' ? [] : explode('/', $path);
}

function bearerToken(): ?string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!$header && function_exists('getallheaders')) {
        $headers = getallheaders();
        $header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }

    if (preg_match('/Bearer\s+(.+)/i', $header, $matches)) {
        return trim($matches[1]);
    }

    return null;
}

function currentUser(?array $allowedRoles = null): array
{
    $token = bearerToken();
    if (!$token) {
        jsonResponse(['ok' => false, 'message' => 'Нужен Bearer токен. Сначала выполни /login.'], 401);
    }

    $sql = <<<SQL
SELECT
    u.user_id,
    u.role_code,
    u.login,
    u.email,
    u.first_name,
    u.last_name,
    u.phone,
    s.store_id,
    s.store_name,
    t.expires_at
FROM auth_tokens t
JOIN app_users u ON u.user_id = t.user_id AND u.is_active = 1
LEFT JOIN stores s ON s.manager_user_id = u.user_id
WHERE t.token = :token AND t.expires_at > NOW()
LIMIT 1
SQL;

    $stmt = db()->prepare($sql);
    $stmt->execute(['token' => $token]);
    $user = $stmt->fetch();

    if (!$user) {
        jsonResponse(['ok' => false, 'message' => 'Токен не найден или истек. Выполни вход заново.'], 401);
    }

    if ($allowedRoles !== null && !in_array($user['role_code'], $allowedRoles, true)) {
        jsonResponse(['ok' => false, 'message' => 'Недостаточно прав для этого действия.'], 403);
    }

    db()->exec('SET @app_user_id = ' . (int) $user['user_id']);
    return $user;
}

function assertFields(array $data, array $fields): void
{
    foreach ($fields as $field) {
        $value = $data[$field] ?? null;
        if ($value === null || (is_string($value) && trim($value) === '')) {
            jsonResponse(['ok' => false, 'message' => 'Не заполнено обязательное поле: ' . $field], 422);
        }
    }
}

function parseDate(?string $value, string $field): string
{
    if (!$value) {
        jsonResponse(['ok' => false, 'message' => 'Не заполнено поле: ' . $field], 422);
    }

    $dt = DateTime::createFromFormat('Y-m-d', $value);
    if (!$dt || $dt->format('Y-m-d') !== $value) {
        jsonResponse(['ok' => false, 'message' => 'Неверный формат даты в поле ' . $field . '. Нужен YYYY-MM-DD.'], 422);
    }

    return $value;
}

function taskById(int $taskId): array
{
    $sql = <<<SQL
SELECT
    t.*, 
    s.store_name,
    r.region_id,
    r.region_name,
    CONCAT_WS(' ', sp.last_name, sp.first_name, sp.middle_name) AS specialist_full_name,
    creator.login AS created_by_login,
    office.login AS assigned_by_login
FROM tasks t
JOIN stores s ON s.store_id = t.store_id
JOIN regions r ON r.region_id = s.region_id
JOIN app_users creator ON creator.user_id = t.created_by_user_id
LEFT JOIN specialists sp ON sp.specialist_id = t.assigned_specialist_id
LEFT JOIN app_users office ON office.user_id = t.assigned_by_user_id
WHERE t.task_id = :task_id
LIMIT 1
SQL;
    $stmt = db()->prepare($sql);
    $stmt->execute(['task_id' => $taskId]);
    $task = $stmt->fetch();

    if (!$task) {
        jsonResponse(['ok' => false, 'message' => 'Задание не найдено.'], 404);
    }

    $itemsStmt = db()->prepare(
        'SELECT twi.task_work_item_id, twi.line_no, twi.work_name, twi.quantity, twi.comment_text, st.specialty_id, st.specialty_name
         FROM task_work_items twi
         JOIN specialties st ON st.specialty_id = twi.specialty_id
         WHERE twi.task_id = :task_id
         ORDER BY twi.line_no'
    );
    $itemsStmt->execute(['task_id' => $taskId]);
    $task['work_items'] = $itemsStmt->fetchAll();

    return $task;
}

function requestById(int $requestId): array
{
    $sql = <<<SQL
SELECT
    rr.*,
    spc.specialty_name,
    rg.region_name,
    t.title AS task_title,
    CONCAT_WS(' ', s.last_name, s.first_name, s.middle_name) AS fulfilled_specialist_name
FROM recruitment_requests rr
JOIN specialties spc ON spc.specialty_id = rr.specialty_id
JOIN regions rg ON rg.region_id = rr.region_id
JOIN tasks t ON t.task_id = rr.task_id
LEFT JOIN specialists s ON s.specialist_id = rr.fulfilled_specialist_id
WHERE rr.recruitment_request_id = :request_id
LIMIT 1
SQL;
    $stmt = db()->prepare($sql);
    $stmt->execute(['request_id' => $requestId]);
    $row = $stmt->fetch();

    if (!$row) {
        jsonResponse(['ok' => false, 'message' => 'HR-заявка не найдена.'], 404);
    }

    return $row;
}

function listTasks(array $user): void
{
    $params = [];
    $where = [];

    if ($user['role_code'] === 'store_manager') {
        $where[] = 't.store_id = :store_id';
        $params['store_id'] = (int) $user['store_id'];
    }

    if (!empty($_GET['status'])) {
        $statuses = array_values(array_filter(array_map('trim', explode(',', (string) $_GET['status']))));
        if ($statuses) {
            $placeholders = [];
            foreach ($statuses as $index => $status) {
                $key = 'status_' . $index;
                $placeholders[] = ':' . $key;
                $params[$key] = $status;
            }
            $where[] = 't.status IN (' . implode(',', $placeholders) . ')';
        }
    }

    if (!empty($_GET['store_id']) && $user['role_code'] !== 'store_manager') {
        $where[] = 't.store_id = :filter_store_id';
        $params['filter_store_id'] = (int) $_GET['store_id'];
    }

    if (!empty($_GET['date_from'])) {
        $where[] = 't.date_start >= :date_from';
        $params['date_from'] = parseDate((string) $_GET['date_from'], 'date_from');
    }

    if (!empty($_GET['date_to'])) {
        $where[] = 't.date_end <= :date_to';
        $params['date_to'] = parseDate((string) $_GET['date_to'], 'date_to');
    }

    $sql = <<<SQL
SELECT
    t.task_id,
    t.title,
    t.description,
    t.date_start,
    t.date_end,
    t.performer_wishes,
    t.status,
    t.created_at,
    t.submitted_at,
    t.assigned_at,
    t.closed_at,
    t.cancelled_at,
    s.store_id,
    s.store_name,
    rg.region_name,
    CONCAT_WS(' ', sp.last_name, sp.first_name, sp.middle_name) AS specialist_full_name
FROM tasks t
JOIN stores s ON s.store_id = t.store_id
JOIN regions rg ON rg.region_id = s.region_id
LEFT JOIN specialists sp ON sp.specialist_id = t.assigned_specialist_id
SQL;

    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }

    $sql .= ' ORDER BY t.created_at DESC, t.task_id DESC';

    $stmt = db()->prepare($sql);
    $stmt->execute($params);

    jsonResponse([
        'ok' => true,
        'items' => $stmt->fetchAll(),
    ]);
}

function taskHistory(int $taskId): array
{
    $stmt = db()->prepare(
        'SELECT h.history_id, h.old_status, h.new_status, h.change_comment, h.changed_at, u.login AS changed_by
         FROM task_status_history h
         LEFT JOIN app_users u ON u.user_id = h.changed_by_user_id
         WHERE h.task_id = :task_id
         ORDER BY h.changed_at ASC, h.history_id ASC'
    );
    $stmt->execute(['task_id' => $taskId]);
    return $stmt->fetchAll();
}

function recruitmentHistory(int $requestId): array
{
    $stmt = db()->prepare(
        'SELECT h.history_id, h.old_status, h.new_status, h.change_comment, h.changed_at, u.login AS changed_by
         FROM recruitment_request_status_history h
         LEFT JOIN app_users u ON u.user_id = h.changed_by_user_id
         WHERE h.recruitment_request_id = :request_id
         ORDER BY h.changed_at ASC, h.history_id ASC'
    );
    $stmt->execute(['request_id' => $requestId]);
    return $stmt->fetchAll();
}

$method = $_SERVER['REQUEST_METHOD'];
$segments = routeSegments();

try {
    if ($method === 'GET' && $segments === ['health']) {
        jsonResponse([
            'ok' => true,
            'message' => 'API работает.',
            'db_time' => db()->query('SELECT NOW() AS now_time')->fetch()['now_time'] ?? null,
        ]);
    }

    if ($method === 'POST' && $segments === ['login']) {
        $data = requestBody();
        assertFields($data, ['username', 'password']);

        $stmt = db()->prepare(
            'SELECT user_id, login, email, password_hash, role_code, first_name, last_name, is_active
             FROM app_users WHERE login = :login LIMIT 1'
        );
        $stmt->execute(['login' => trim((string) $data['username'])]);
        $user = $stmt->fetch();

        if (!$user || !(bool) $user['is_active'] || !password_verify((string) $data['password'], (string) $user['password_hash'])) {
            jsonResponse(['ok' => false, 'message' => 'Неверный логин или пароль.'], 401);
        }

        $token = bin2hex(random_bytes(32));
        $expiresAt = (new DateTimeImmutable())->modify('+' . (int) $config['token_ttl_hours'] . ' hours')->format('Y-m-d H:i:s');

        db()->prepare('INSERT INTO auth_tokens (user_id, token, expires_at) VALUES (:user_id, :token, :expires_at)')
            ->execute([
                'user_id' => $user['user_id'],
                'token' => $token,
                'expires_at' => $expiresAt,
            ]);

        $storeStmt = db()->prepare('SELECT store_id, store_name FROM stores WHERE manager_user_id = :user_id LIMIT 1');
        $storeStmt->execute(['user_id' => $user['user_id']]);
        $store = $storeStmt->fetch() ?: ['store_id' => null, 'store_name' => null];

        jsonResponse([
            'ok' => true,
            'token' => $token,
            'expires_at' => $expiresAt,
            'user' => [
                'user_id' => (int) $user['user_id'],
                'login' => $user['login'],
                'email' => $user['email'],
                'role_code' => $user['role_code'],
                'full_name' => trim($user['first_name'] . ' ' . $user['last_name']),
                'store_id' => $store['store_id'] !== null ? (int) $store['store_id'] : null,
                'store_name' => $store['store_name'],
            ],
        ]);
    }

    if ($method === 'GET' && $segments === ['me']) {
        $user = currentUser();
        jsonResponse(['ok' => true, 'user' => $user]);
    }

    if ($method === 'GET' && $segments === ['stores']) {
        currentUser();
        $items = db()->query('SELECT store_id, store_name, address FROM stores WHERE is_active = 1 ORDER BY store_name')->fetchAll();
        jsonResponse(['ok' => true, 'items' => $items]);
    }

    if ($method === 'GET' && $segments === ['specialties']) {
        currentUser();
        $items = db()->query('SELECT specialty_id, specialty_name, description FROM specialties ORDER BY specialty_name')->fetchAll();
        jsonResponse(['ok' => true, 'items' => $items]);
    }

    if ($method === 'GET' && $segments === ['tasks']) {
        $user = currentUser(['store_manager', 'office_manager']);
        listTasks($user);
    }

    if ($method === 'GET' && count($segments) === 2 && $segments[0] === 'tasks' && ctype_digit($segments[1])) {
        $user = currentUser(['store_manager', 'office_manager']);
        $task = taskById((int) $segments[1]);

        if ($user['role_code'] === 'store_manager' && (int) $task['store_id'] !== (int) $user['store_id']) {
            jsonResponse(['ok' => false, 'message' => 'Нет доступа к чужому заданию.'], 403);
        }

        $task['history'] = taskHistory((int) $task['task_id']);
        jsonResponse(['ok' => true, 'item' => $task]);
    }

    if ($method === 'POST' && $segments === ['tasks']) {
        $user = currentUser(['store_manager']);
        $data = requestBody();
        assertFields($data, ['title', 'date_start', 'date_end']);

        $title = trim((string) $data['title']);
        $description = trim((string) ($data['description'] ?? ''));
        $dateStart = parseDate((string) $data['date_start'], 'date_start');
        $dateEnd = parseDate((string) $data['date_end'], 'date_end');
        $performerWishes = trim((string) ($data['performer_wishes'] ?? ''));
        $workItems = is_array($data['work_items'] ?? null) ? $data['work_items'] : [];

        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO tasks (store_id, created_by_user_id, title, description, date_start, date_end, performer_wishes, status)
                 VALUES (:store_id, :created_by_user_id, :title, :description, :date_start, :date_end, :performer_wishes, "new")'
            );
            $stmt->execute([
                'store_id' => (int) $user['store_id'],
                'created_by_user_id' => (int) $user['user_id'],
                'title' => $title,
                'description' => $description !== '' ? $description : null,
                'date_start' => $dateStart,
                'date_end' => $dateEnd,
                'performer_wishes' => $performerWishes !== '' ? $performerWishes : null,
            ]);
            $taskId = (int) $pdo->lastInsertId();

            if ($workItems) {
                $insertItem = $pdo->prepare(
                    'INSERT INTO task_work_items (task_id, line_no, work_name, specialty_id, quantity, comment_text)
                     VALUES (:task_id, :line_no, :work_name, :specialty_id, :quantity, :comment_text)'
                );
                $lineNo = 1;
                foreach ($workItems as $item) {
                    if (!is_array($item)) {
                        continue;
                    }
                    $workName = trim((string) ($item['work_name'] ?? ''));
                    $specialtyId = (int) ($item['specialty_id'] ?? 0);
                    if ($workName === '' || $specialtyId <= 0) {
                        continue;
                    }
                    $insertItem->execute([
                        'task_id' => $taskId,
                        'line_no' => $lineNo++,
                        'work_name' => $workName,
                        'specialty_id' => $specialtyId,
                        'quantity' => (float) ($item['quantity'] ?? 1),
                        'comment_text' => trim((string) ($item['comment_text'] ?? '')) ?: null,
                    ]);
                }
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        jsonResponse(['ok' => true, 'message' => 'Черновик задания создан.', 'item' => taskById($taskId)], 201);
    }

    if ($method === 'PUT' && count($segments) === 2 && $segments[0] === 'tasks' && ctype_digit($segments[1])) {
        $user = currentUser(['store_manager']);
        $task = taskById((int) $segments[1]);
        if ((int) $task['store_id'] !== (int) $user['store_id']) {
            jsonResponse(['ok' => false, 'message' => 'Нельзя редактировать чужое задание.'], 403);
        }
        if ($task['status'] !== 'new') {
            jsonResponse(['ok' => false, 'message' => 'Редактирование доступно только для задания в статусе new.'], 409);
        }

        $data = requestBody();
        $title = trim((string) ($data['title'] ?? $task['title']));
        $description = trim((string) ($data['description'] ?? $task['description'] ?? ''));
        $dateStart = parseDate((string) ($data['date_start'] ?? $task['date_start']), 'date_start');
        $dateEnd = parseDate((string) ($data['date_end'] ?? $task['date_end']), 'date_end');
        $performerWishes = trim((string) ($data['performer_wishes'] ?? $task['performer_wishes'] ?? ''));

        db()->prepare(
            'UPDATE tasks SET title = :title, description = :description, date_start = :date_start, date_end = :date_end, performer_wishes = :performer_wishes WHERE task_id = :task_id'
        )->execute([
            'title' => $title,
            'description' => $description !== '' ? $description : null,
            'date_start' => $dateStart,
            'date_end' => $dateEnd,
            'performer_wishes' => $performerWishes !== '' ? $performerWishes : null,
            'task_id' => (int) $task['task_id'],
        ]);

        jsonResponse(['ok' => true, 'message' => 'Задание обновлено.', 'item' => taskById((int) $task['task_id'])]);
    }

    if ($method === 'POST' && count($segments) === 3 && $segments[0] === 'tasks' && ctype_digit($segments[1]) && $segments[2] === 'submit') {
        $user = currentUser(['store_manager']);
        $task = taskById((int) $segments[1]);
        if ((int) $task['store_id'] !== (int) $user['store_id']) {
            jsonResponse(['ok' => false, 'message' => 'Нельзя отправить чужое задание.'], 403);
        }
        if ($task['status'] !== 'new') {
            jsonResponse(['ok' => false, 'message' => 'Отправить в офис можно только задание в статусе new.'], 409);
        }
        if (trim((string) $task['title']) === '' || trim((string) $task['date_start']) === '' || trim((string) $task['date_end']) === '') {
            jsonResponse(['ok' => false, 'message' => 'Заполни обязательные поля перед отправкой.'], 422);
        }

        db()->prepare('UPDATE tasks SET status = "in_work" WHERE task_id = :task_id')->execute(['task_id' => (int) $task['task_id']]);
        jsonResponse(['ok' => true, 'message' => 'Задание отправлено в офис.', 'item' => taskById((int) $task['task_id'])]);
    }

    if ($method === 'POST' && count($segments) === 3 && $segments[0] === 'tasks' && ctype_digit($segments[1]) && $segments[2] === 'cancel') {
        $user = currentUser(['store_manager']);
        $task = taskById((int) $segments[1]);
        if ((int) $task['store_id'] !== (int) $user['store_id']) {
            jsonResponse(['ok' => false, 'message' => 'Нельзя отменить чужое задание.'], 403);
        }
        if (!in_array($task['status'], ['new', 'in_work'], true)) {
            jsonResponse(['ok' => false, 'message' => 'Отмена доступна только для статусов new и in_work.'], 409);
        }

        db()->prepare('UPDATE tasks SET status = "cancelled" WHERE task_id = :task_id')->execute(['task_id' => (int) $task['task_id']]);
        jsonResponse(['ok' => true, 'message' => 'Задание отменено.', 'item' => taskById((int) $task['task_id'])]);
    }

    if ($method === 'GET' && $segments === ['specialists']) {
        currentUser(['office_manager', 'hr_specialist']);
        $params = [];
        $where = [];

        if (!empty($_GET['specialty_id'])) {
            $where[] = 'ss.specialty_id = :specialty_id';
            $params['specialty_id'] = (int) $_GET['specialty_id'];
        }
        if (!empty($_GET['region_id'])) {
            $where[] = 'sp.region_id = :region_id';
            $params['region_id'] = (int) $_GET['region_id'];
        }
        if (!empty($_GET['contract_status'])) {
            $where[] = 'sp.contract_status = :contract_status';
            $params['contract_status'] = trim((string) $_GET['contract_status']);
        }
        if (isset($_GET['is_available']) && $_GET['is_available'] !== '') {
            $where[] = 'sp.is_available = :is_available';
            $params['is_available'] = (int) $_GET['is_available'];
        }

        $sql = <<<SQL
SELECT
    sp.specialist_id,
    CONCAT_WS(' ', sp.last_name, sp.first_name, sp.middle_name) AS specialist_full_name,
    sp.phone,
    sp.email,
    sp.contract_status,
    sp.is_available,
    rg.region_name,
    GROUP_CONCAT(DISTINCT st.specialty_name ORDER BY st.specialty_name SEPARATOR ', ') AS specialties
FROM specialists sp
JOIN regions rg ON rg.region_id = sp.region_id
LEFT JOIN specialist_specialties ss ON ss.specialist_id = sp.specialist_id
LEFT JOIN specialties st ON st.specialty_id = ss.specialty_id
SQL;
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' GROUP BY sp.specialist_id, sp.last_name, sp.first_name, sp.middle_name, sp.phone, sp.email, sp.contract_status, sp.is_available, rg.region_name ORDER BY specialist_full_name';

        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        jsonResponse(['ok' => true, 'items' => $stmt->fetchAll()]);
    }

    if ($method === 'POST' && count($segments) === 3 && $segments[0] === 'tasks' && ctype_digit($segments[1]) && $segments[2] === 'assign-specialist') {
        $user = currentUser(['office_manager']);
        $task = taskById((int) $segments[1]);
        if ($task['status'] !== 'in_work') {
            jsonResponse(['ok' => false, 'message' => 'Назначение доступно только для заданий в статусе in_work.'], 409);
        }

        $data = requestBody();
        $specialistId = (int) ($data['specialist_id'] ?? 0);
        if ($specialistId <= 0) {
            jsonResponse(['ok' => false, 'message' => 'Укажи specialist_id.'], 422);
        }

        $stmt = db()->prepare('SELECT specialist_id, contract_status, is_available, region_id FROM specialists WHERE specialist_id = :specialist_id LIMIT 1');
        $stmt->execute(['specialist_id' => $specialistId]);
        $specialist = $stmt->fetch();
        if (!$specialist) {
            jsonResponse(['ok' => false, 'message' => 'Специалист не найден.'], 404);
        }
        if ($specialist['contract_status'] !== 'active' || (int) $specialist['is_available'] !== 1) {
            jsonResponse(['ok' => false, 'message' => 'Специалист должен быть активным и доступным.'], 409);
        }

        db()->prepare(
            'UPDATE tasks
             SET assigned_specialist_id = :specialist_id,
                 assigned_by_user_id = :user_id,
                 status = "completed"
             WHERE task_id = :task_id'
        )->execute([
            'specialist_id' => $specialistId,
            'user_id' => (int) $user['user_id'],
            'task_id' => (int) $task['task_id'],
        ]);

        jsonResponse(['ok' => true, 'message' => 'Специалист назначен, задание переведено в completed.', 'item' => taskById((int) $task['task_id'])]);
    }

    if ($method === 'POST' && count($segments) === 3 && $segments[0] === 'tasks' && ctype_digit($segments[1]) && $segments[2] === 'close') {
        currentUser(['office_manager']);
        $task = taskById((int) $segments[1]);
        if ($task['status'] !== 'completed') {
            jsonResponse(['ok' => false, 'message' => 'Закрыть можно только задание в статусе completed.'], 409);
        }

        db()->prepare('UPDATE tasks SET status = "closed" WHERE task_id = :task_id')->execute(['task_id' => (int) $task['task_id']]);
        jsonResponse(['ok' => true, 'message' => 'Задание закрыто.', 'item' => taskById((int) $task['task_id'])]);
    }

    if ($method === 'POST' && count($segments) === 3 && $segments[0] === 'tasks' && ctype_digit($segments[1]) && $segments[2] === 'recruitment-requests') {
        $user = currentUser(['office_manager']);
        $task = taskById((int) $segments[1]);
        if ($task['status'] !== 'in_work') {
            jsonResponse(['ok' => false, 'message' => 'Создать HR-заявку можно только для задания в статусе in_work.'], 409);
        }

        $data = requestBody();
        assertFields($data, ['specialty_id']);
        $specialtyId = (int) $data['specialty_id'];
        $note = trim((string) ($data['notes'] ?? '')) ?: 'Подходящий специалист в базе не найден.';

        $check = db()->prepare('SELECT recruitment_request_id FROM recruitment_requests WHERE task_id = :task_id AND specialty_id = :specialty_id LIMIT 1');
        $check->execute(['task_id' => (int) $task['task_id'], 'specialty_id' => $specialtyId]);
        if ($check->fetch()) {
            jsonResponse(['ok' => false, 'message' => 'По этому заданию и специализации HR-заявка уже существует.'], 409);
        }

        db()->prepare(
            'INSERT INTO recruitment_requests (task_id, specialty_id, region_id, created_by_user_id, status, notes, needed_from, needed_to)
             VALUES (:task_id, :specialty_id, :region_id, :created_by_user_id, "new", :notes, :needed_from, :needed_to)'
        )->execute([
            'task_id' => (int) $task['task_id'],
            'specialty_id' => $specialtyId,
            'region_id' => (int) $task['region_id'],
            'created_by_user_id' => (int) $user['user_id'],
            'notes' => $note,
            'needed_from' => $task['date_start'],
            'needed_to' => $task['date_end'],
        ]);

        $requestId = (int) db()->lastInsertId();
        jsonResponse(['ok' => true, 'message' => 'Заявка на подбор создана.', 'item' => requestById($requestId)], 201);
    }

    if ($method === 'GET' && $segments === ['recruitment-requests']) {
        $user = currentUser(['office_manager', 'hr_specialist']);
        $params = [];
        $where = [];

        if (!empty($_GET['status'])) {
            $statuses = array_values(array_filter(array_map('trim', explode(',', (string) $_GET['status']))));
            if ($statuses) {
                $parts = [];
                foreach ($statuses as $index => $status) {
                    $key = 'rr_status_' . $index;
                    $parts[] = ':' . $key;
                    $params[$key] = $status;
                }
                $where[] = 'rr.status IN (' . implode(',', $parts) . ')';
            }
        }

        if (!empty($_GET['task_id'])) {
            $where[] = 'rr.task_id = :task_id';
            $params['task_id'] = (int) $_GET['task_id'];
        }

        $sql = <<<SQL
SELECT
    rr.recruitment_request_id,
    rr.task_id,
    rr.status,
    rr.notes,
    rr.needed_from,
    rr.needed_to,
    rr.created_at,
    rr.started_at,
    rr.fulfilled_at,
    t.title AS task_title,
    spc.specialty_name,
    rg.region_name,
    creator.login AS created_by,
    hr.login AS hr_login,
    CONCAT_WS(' ', s.last_name, s.first_name, s.middle_name) AS fulfilled_specialist_name
FROM recruitment_requests rr
JOIN tasks t ON t.task_id = rr.task_id
JOIN specialties spc ON spc.specialty_id = rr.specialty_id
JOIN regions rg ON rg.region_id = rr.region_id
JOIN app_users creator ON creator.user_id = rr.created_by_user_id
LEFT JOIN app_users hr ON hr.user_id = rr.hr_user_id
LEFT JOIN specialists s ON s.specialist_id = rr.fulfilled_specialist_id
SQL;
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY rr.created_at DESC, rr.recruitment_request_id DESC';

        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        $items = $stmt->fetchAll();

        if ($user['role_code'] === 'office_manager') {
            // office sees all requests
        }

        jsonResponse(['ok' => true, 'items' => $items]);
    }

    if ($method === 'GET' && count($segments) === 2 && $segments[0] === 'recruitment-requests' && ctype_digit($segments[1])) {
        currentUser(['office_manager', 'hr_specialist']);
        $item = requestById((int) $segments[1]);
        $item['history'] = recruitmentHistory((int) $item['recruitment_request_id']);
        jsonResponse(['ok' => true, 'item' => $item]);
    }

    if ($method === 'POST' && count($segments) === 3 && $segments[0] === 'recruitment-requests' && ctype_digit($segments[1]) && $segments[2] === 'take') {
        $user = currentUser(['hr_specialist']);
        $item = requestById((int) $segments[1]);
        if ($item['status'] !== 'new') {
            jsonResponse(['ok' => false, 'message' => 'Взять в работу можно только HR-заявку в статусе new.'], 409);
        }

        db()->prepare(
            'UPDATE recruitment_requests SET status = "in_work", hr_user_id = :hr_user_id WHERE recruitment_request_id = :request_id'
        )->execute([
            'hr_user_id' => (int) $user['user_id'],
            'request_id' => (int) $item['recruitment_request_id'],
        ]);

        jsonResponse(['ok' => true, 'message' => 'HR-заявка взята в работу.', 'item' => requestById((int) $item['recruitment_request_id'])]);
    }

    if ($method === 'POST' && $segments === ['specialists']) {
        $user = currentUser(['hr_specialist']);
        $data = requestBody();
        assertFields($data, ['last_name', 'first_name', 'region_id', 'specialty_ids']);

        $specialtyIds = array_values(array_filter(array_map('intval', is_array($data['specialty_ids']) ? $data['specialty_ids'] : [])));
        if (!$specialtyIds) {
            jsonResponse(['ok' => false, 'message' => 'Укажи хотя бы одну специализацию.'], 422);
        }

        $pdo = db();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO specialists (last_name, first_name, middle_name, phone, email, region_id, contract_status, is_available, hire_date, contract_number, notes, created_by_user_id)
                 VALUES (:last_name, :first_name, :middle_name, :phone, :email, :region_id, :contract_status, :is_available, :hire_date, :contract_number, :notes, :created_by_user_id)'
            );
            $stmt->execute([
                'last_name' => trim((string) $data['last_name']),
                'first_name' => trim((string) $data['first_name']),
                'middle_name' => trim((string) ($data['middle_name'] ?? '')) ?: null,
                'phone' => trim((string) ($data['phone'] ?? '')) ?: null,
                'email' => trim((string) ($data['email'] ?? '')) ?: null,
                'region_id' => (int) $data['region_id'],
                'contract_status' => trim((string) ($data['contract_status'] ?? 'active')),
                'is_available' => isset($data['is_available']) ? (int) !!$data['is_available'] : 1,
                'hire_date' => !empty($data['hire_date']) ? parseDate((string) $data['hire_date'], 'hire_date') : null,
                'contract_number' => trim((string) ($data['contract_number'] ?? '')) ?: null,
                'notes' => trim((string) ($data['notes'] ?? '')) ?: null,
                'created_by_user_id' => (int) $user['user_id'],
            ]);
            $specialistId = (int) $pdo->lastInsertId();

            $linkStmt = $pdo->prepare(
                'INSERT INTO specialist_specialties (specialist_id, specialty_id, proficiency_level) VALUES (:specialist_id, :specialty_id, :proficiency_level)'
            );
            foreach ($specialtyIds as $specialtyId) {
                $linkStmt->execute([
                    'specialist_id' => $specialistId,
                    'specialty_id' => $specialtyId,
                    'proficiency_level' => 3,
                ]);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        jsonResponse(['ok' => true, 'message' => 'Новый специалист добавлен в базу.', 'specialist_id' => $specialistId], 201);
    }

    if ($method === 'POST' && count($segments) === 3 && $segments[0] === 'recruitment-requests' && ctype_digit($segments[1]) && $segments[2] === 'fulfill') {
        $user = currentUser(['hr_specialist']);
        $item = requestById((int) $segments[1]);
        if ($item['status'] !== 'in_work') {
            jsonResponse(['ok' => false, 'message' => 'Завершить можно только HR-заявку в статусе in_work.'], 409);
        }

        $data = requestBody();
        $specialistId = (int) ($data['fulfilled_specialist_id'] ?? 0);
        if ($specialistId <= 0) {
            jsonResponse(['ok' => false, 'message' => 'Укажи fulfilled_specialist_id.'], 422);
        }

        db()->prepare(
            'UPDATE recruitment_requests
             SET status = "fulfilled", hr_user_id = :hr_user_id, fulfilled_specialist_id = :specialist_id
             WHERE recruitment_request_id = :request_id'
        )->execute([
            'hr_user_id' => (int) $user['user_id'],
            'specialist_id' => $specialistId,
            'request_id' => (int) $item['recruitment_request_id'],
        ]);

        jsonResponse(['ok' => true, 'message' => 'HR-заявка исполнена.', 'item' => requestById((int) $item['recruitment_request_id'])]);
    }

    jsonResponse(['ok' => false, 'message' => 'Маршрут не найден: ' . $method . ' ' . normalizePath()], 404);
} catch (PDOException $e) {
    jsonResponse([
        'ok' => false,
        'message' => 'Ошибка базы данных.',
        'error' => $e->getMessage(),
    ], 500);
} catch (Throwable $e) {
    jsonResponse([
        'ok' => false,
        'message' => 'Ошибка сервера.',
        'error' => $e->getMessage(),
    ], 500);
}
