<?php
return [
    'db' => [
        'host' => 'localhost',
        'port' => 3306,
        'name' => 'service_jobs_xampp',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],
    'token_ttl_hours' => 24,
];
